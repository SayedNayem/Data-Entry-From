# Data Entry Form(prac)

A Pen created on CodePen.io. Original URL: [https://codepen.io/sayednayem6992/pen/QWrrKEe](https://codepen.io/sayednayem6992/pen/QWrrKEe).

